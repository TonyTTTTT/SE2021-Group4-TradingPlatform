public class Switch {

   private int packageNum;

   private String currentDirection;

   private void getCurrentCondition() {

   }

}
