public class SensorResult {

   private int time;

   private boolean isIn;

   private int packageNum;

   private Switch aSwitch;

   private String direction;

}
