import java.util.List;

public class Pipe {

   private int packageNum;

   private List<Package> packages;

}
