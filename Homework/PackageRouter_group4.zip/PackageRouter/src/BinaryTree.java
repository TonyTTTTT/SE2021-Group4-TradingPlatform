import java.util.List;

public class BinaryTree {

   private Switch root;

   private List<Switch> switches;

}
