public class Sensor {
}
